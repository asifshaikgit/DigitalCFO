package model;

public class PwcUserInfoResponse {
    public String given_name;
    public String family_name;
    public String name;
    public String uid;
    public String preferredMail;
    public String email;
    public String sub;
    public String realm;
    public String aud;
    public String upn;
}
