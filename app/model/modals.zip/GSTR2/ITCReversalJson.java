package model.GSTR2;

public class ITCReversalJson {

}
