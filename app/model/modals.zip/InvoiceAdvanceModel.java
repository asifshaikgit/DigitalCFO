package model;
/**
 * Created by Sunil Namdev on 30-08-2017.
 */
public class InvoiceAdvanceModel {
    private String arvNo;
    private String advDate;
    private String totalAdvReceived;
    private String advanceAdjusted;
    private String advTaxableValue;
    private String advAdjTax1;
    private String advAdjTax2;
    private String advAdjTax3;
    private String advAdjTax4;

    public String getArvNo() {
        return this.arvNo;
    }

    public void setArvNo(String arvNo) {
        this.arvNo = arvNo;
    }

    public String getAdvDate() {
        return this.advDate;
    }

    public void setAdvDate(String advDate) {
        this.advDate = advDate;
    }

    public String getTotalAdvReceived() {
        return this.totalAdvReceived;
    }

    public void setTotalAdvReceived(String totalAdvReceived) {
        this.totalAdvReceived = totalAdvReceived;
    }

    public String getAdvanceAdjusted() {
        return this.advanceAdjusted;
    }

    public void setAdvanceAdjusted(String advanceAdjusted) {
        this.advanceAdjusted = advanceAdjusted;
    }

    public String getAdvTaxableValue() {
        return this.advTaxableValue;
    }

    public void setAdvTaxableValue(String advTaxableValue) {
        this.advTaxableValue = advTaxableValue;
    }

    public String getAdvAdjTax1() {
        return this.advAdjTax1;
    }

    public void setAdvAdjTax1(String advAdjTax1) {
        this.advAdjTax1 = advAdjTax1;
    }

    public String getAdvAdjTax2() {
        return this.advAdjTax2;
    }

    public void setAdvAdjTax2(String advAdjTax2) {
        this.advAdjTax2 = advAdjTax2;
    }

    public String getAdvAdjTax3() {
        return this.advAdjTax3;
    }

    public void setAdvAdjTax3(String advAdjTax3) {
        this.advAdjTax3 = advAdjTax3;
    }

    public String getAdvAdjTax4() {
        return this.advAdjTax4;
    }

    public void setAdvAdjTax4(String advAdjTax4) {
        this.advAdjTax4 = advAdjTax4;
    }
}
