package model;

/**
 * Created by Sunil Namdev on 18-10-2016.
 */
public interface IReport {
}
