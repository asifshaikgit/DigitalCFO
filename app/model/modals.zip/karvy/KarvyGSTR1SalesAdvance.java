package model.karvy;

import java.util.List;

public class KarvyGSTR1SalesAdvance {
	List salestaxinvlist;

	public List getSalestaxinvlist() {
		return salestaxinvlist;
	}

	public void setSalestaxinvlist(List salestaxinvlist) {
		this.salestaxinvlist = salestaxinvlist;
	}	
	
	
}
