package model.karvy;

import java.util.List;

public class KarvyGSTR2PurchaseInvoice {
	List purchaseinvoicelist;

	public List getPurchaseinvoicelist() {
		return purchaseinvoicelist;
	}

	public void setPurchaseinvoicelist(List purchaseinvoicelist) {
		this.purchaseinvoicelist = purchaseinvoicelist;
	}
	
	
}
