package model.karvy;

public class KarvySalesAdvance {
	String processgstin="";
	String branchcode="";
	String gstin="";	
	String receiverName="";
	String statecode="";
	String pos="";
	String documentno="";
	String documentdate="";
	String isExmpted="Taxable";	
	String hsnsac="";
	String description="";
	String productid="";
	String uqc="Pcs";
	Double quantity=0.0;
	Double amount=0.0;	
	Double igstrate=0.0;   
	Double igstamount=0.0;  
	Double cgstrate=0.0;
	Double cgstamount=0.0;
	Double sgstrate=0.0;
	Double sgstamount=0.0;	
	Double cessamount=0.0;
	Double utgstrate=0.0;
	Double utgstamount=0.0;
	String cancelled="No";
	public String getProcessgstin() {
		return processgstin;
	}
	public void setProcessgstin(String processgstin) {
		this.processgstin = processgstin;
	}
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}	
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getStatecode() {
		return statecode;
	}
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getDocumentno() {
		return documentno;
	}
	public void setDocumentno(String documentno) {
		this.documentno = documentno;
	}
	public String getDocumentdate() {
		return documentdate;
	}
	public void setDocumentdate(String documentdate) {
		this.documentdate = documentdate;
	}
	public String getIsExmpted() {
		return isExmpted;
	}
	public void setIsExmpted(String isExmpted) {
		this.isExmpted = isExmpted;
	}
	public String getHsnsac() {
		return hsnsac;
	}
	public void setHsnsac(String hsnsac) {
		this.hsnsac = hsnsac;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getUqc() {
		return uqc;
	}
	public void setUqc(String uqc) {
		this.uqc = uqc;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Double getIgstrate() {
		return igstrate;
	}
	public void setIgstrate(Double igstrate) {
		this.igstrate = igstrate;
	}
	public Double getIgstamount() {
		return igstamount;
	}
	public void setIgstamount(Double igstamount) {
		this.igstamount = igstamount;
	}
	public Double getCgstrate() {
		return cgstrate;
	}
	public void setCgstrate(Double cgstrate) {
		this.cgstrate = cgstrate;
	}
	public Double getCgstamount() {
		return cgstamount;
	}
	public void setCgstamount(Double cgstamount) {
		this.cgstamount = cgstamount;
	}
	public Double getSgstrate() {
		return sgstrate;
	}
	public void setSgstrate(Double sgstrate) {
		this.sgstrate = sgstrate;
	}
	public Double getSgstamount() {
		return sgstamount;
	}
	public void setSgstamount(Double sgstamount) {
		this.sgstamount = sgstamount;
	}
	public Double getCessamount() {
		return cessamount;
	}
	public void setCessamount(Double cessamount) {
		this.cessamount = cessamount;
	}
	public Double getUtgstrate() {
		return utgstrate;
	}
	public void setUtgstrate(Double utgstrate) {
		this.utgstrate = utgstrate;
	}
	public Double getUtgstamount() {
		return utgstamount;
	}
	public void setUtgstamount(Double utgstamount) {
		this.utgstamount = utgstamount;
	}
	public String getCancelled() {
		return cancelled;
	}
	public void setCancelled(String cancelled) {
		this.cancelled = cancelled;
	}
	
	
	
}
