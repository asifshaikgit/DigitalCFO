package model.karvy;

import java.util.List;

public class KarvyGSTR1SalesInvoice {
	List salesinvoicelist;

	public List getSalesinvoicelist() {
		return salesinvoicelist;
	}

	public void setSalesinvoicelist(List salesinvoicelist) {
		this.salesinvoicelist = salesinvoicelist;
	}
	
}
