package model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="SPECIFICS_TRANSACTION_PURPOSE")
public class SpecificsTransactionPurpose extends AbstractBaseModel {
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TRANSACTION_PURPOSE_ID")
	private TransactionPurpose transactionPurpose;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SPECIFICS_ID")
	private Specifics specifics;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SPECIFICS_PARTICULARS_ID")
	private Particulars particulars;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BRANCH_ID")
	private Branch branch;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BRANCH_ORGANIZATION_ID")
	private Organization organization;
	
	public TransactionPurpose getTransactionPurpose() {
		return transactionPurpose;
	}

	public void setTransactionPurpose(TransactionPurpose transactionPurpose) {
		this.transactionPurpose = transactionPurpose;
	}

	public Specifics getSpecifics() {
		return specifics;
	}

	public void setSpecifics(Specifics specifics) {
		this.specifics = specifics;
	}

	public Particulars getParticulars() {
		return particulars;
	}

	public void setParticulars(Particulars particulars) {
		this.particulars = particulars;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Organization getOrganization() {
		return organization;
	}

	public void setOrganization(Organization organization) {
		this.organization = organization;
	}
	
	public Long getEntityComparableParamId(){
		if(getTransactionPurpose() == null){
			return new Long(0);
		}else {
			return getTransactionPurpose().getId();
		}
	}	
}
