package model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="SPECIFICS_has_KNOWLEDGE_LIBRARY_for_BRANCH")
public class SpecificsKnowledgeLibraryForBranch extends AbstractBaseModel {
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="branch_id")
	private Branch branch;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="branch_organization_id")
	private Organization organization;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="specifics_id")
	private Specifics specifics;
	

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="specifics_particulars_id")
	private Particulars particulars;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="KNOWLEDGE_LIBRARY_ID")
	private SpecificsKnowledgeLibrary specificsKl;
	
	public SpecificsKnowledgeLibrary getSpecificsKl() {
		return specificsKl;
	}

	public void setSpecificsKl(SpecificsKnowledgeLibrary specificsKl) {
		this.specificsKl = specificsKl;
	}
	
	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Organization getOrganization() {
		return organization;
	}

	public void setOrganization(Organization organization) {
		this.organization = organization;
	}

	public Specifics getSpecifics() {
		return specifics;
	}

	public void setSpecifics(Specifics specifics) {
		this.specifics = specifics;
	}

	public Particulars getParticulars() {
		return particulars;
	}

	public void setParticulars(Particulars particulars) {
		this.particulars = particulars;
	}
	
	public Long getEntityComparableParamId(){
		return getBranch().getId();
	}	
}
