package model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.idos.util.IdosUtil;
import play.db.jpa.JPAApi;
import javax.inject.Inject;
import javax.persistence.EntityManager;

@Entity
@Table(name="EXPENSE_GROUP")
public class ExpenseGroup extends AbstractBaseModel {
	private static JPAApi jpaApi;
	private static EntityManager entityManager;

	@Column(name="EXPENSE_GROUP_NAME")
	private String expenseGroupName;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORGANIZATION_ID")
	private Organization organization;
	
	@OneToMany(mappedBy = "expenseGroup", fetch = FetchType.LAZY)
	private List<ExpenseGroupExpenseItemMonetoryClaim> expenseGroupExpenseItemMonetoryClaims;

	public String getExpenseGroupName() {
		return expenseGroupName;
	}

	public void setExpenseGroupName(String expenseGroupName) {
		this.expenseGroupName = IdosUtil.escapeHtml(expenseGroupName);
	}

	public Organization getOrganization() {
		return organization;
	}

	public void setOrganization(Organization organization) {
		this.organization = organization;
	}
	
	public List<ExpenseGroupExpenseItemMonetoryClaim> getExpenseGroupExpenseItemMonetoryClaims() {
		return expenseGroupExpenseItemMonetoryClaims;
	}

	public void setExpenseGroupExpenseItemMonetoryClaims(
			List<ExpenseGroupExpenseItemMonetoryClaim> expenseGroupExpenseItemMonetoryClaims) {
		this.expenseGroupExpenseItemMonetoryClaims = expenseGroupExpenseItemMonetoryClaims;
	}
	
	/**
     * Find a ExpenseGroup by id.
     */
    public static ExpenseGroup findById(Long id) {
        return entityManager.find(ExpenseGroup.class, id);
    }
}
